<!DOCTYPE html>
<html>
<head>
	<title>Admin Pannel</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/mobile.css">
	<link href="//maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
</head>
<body>
<nav>
	<div class="mobile-header">
		<div class="container">
			<div class="row">
				<div class="col">
					<div class="m-pd-top-bm-md">
						<a href="index_mobile.php" title=""><i class="fa fa-home fa-2x" aria-hidden="true"></i></a>
					</div>
					
				</div>
			</div>
			</div>
		</div><!-- .mobile-header -->
		
</nav>	