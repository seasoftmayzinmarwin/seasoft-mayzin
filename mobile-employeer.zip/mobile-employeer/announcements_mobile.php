<?php include('layout/mobile_header.php') ?>
	<div class="content">
		<div>
			<div class="search-header">
			<div class="container">
				<div class="row">
					<div class="col">
						<div class="c-m-page-header__title">
							<h1 class="c-m-heading c-m-heading--white">お知らせ</h1>

						</div>
					</div>
					</div>
				</div>
			</div>
		</div>
		</div>
		<div class="container">
			<div class="c-m-box c-m-box--bg-white">
				<ul class="c-m-bordered-list">
					</li>
					<li class='c-m-bordered-list__item'>
						<a class="un-link m-display-block" href="" data-toggle="modal" data-target="#announcement-popup" title="">
							<div class="c-m-box c-m-box--vertical-xl c-m-box--horizontal-m">
								<div class="">
									<div class="ds-o-flex__item"><h1 class="c-m-heading c-m-heading--l">採用単価表変更のお知らせ</h1></div>
									<div class="ds-o-flex__item"><span class="c-m-text c-m-text--grey m-fw-bold c-m-text--helvetica c-m-text--s-short">2018/11/20 00:11</span></div>
								</div>
							</div>
						</a>
					</li>
					<li class='c-m-bordered-list__item'>
						<a class="un-link m-display-block" href="" title="">
							<div class="c-m-box c-m-box--vertical-xl c-m-box--horizontal-m">
							<div class="">
								<div class="ds-o-flex__item"><h1 class="c-m-heading c-m-heading--l">採用単価表変更のお知らせ</h1></div>
								<div class="ds-o-flex__item"><span class="c-m-text c-m-text--grey m-fw-bold c-m-text--helvetica c-m-text--s-short">2018/11/20 00:11</span></div>
							</div>
						</div>
						</a>
					</li>
					<li class="c-m-bordered-list__item">
						<a class="un-link m-display-block" href="" title="">
							<div class="c-m-box c-m-box--vertical-xl c-m-box--horizontal-m">
							<div class="">
								<div class="ds-o-flex__item"><h1 class="c-m-heading c-m-heading--l">採用単価表変更のお知らせ</h1></div>
								<div class="ds-o-flex__item"><span class="c-m-text c-m-text--grey m-fw-bold c-m-text--helvetica c-m-text--s-short">2018/11/20 00:11</span></div>
							</div>
						</div>
						</a>
					</li>
					<li class="c-m-bordered-list__item">
						<a class="un-link m-display-block" href="" title="">
							<div class="c-m-box c-m-box--vertical-xl c-m-box--horizontal-m">
							<div class="">
								<div class="ds-o-flex__item"><h1 class="c-m-heading c-m-heading--l">採用単価表変更のお知らせ</h1></div>
								<div class="ds-o-flex__item"><span class="c-m-text c-m-text--grey m-fw-bold c-m-text--helvetica c-m-text--s-short">2018/11/20 00:11</span></div>
							</div>
						</div>
						</a>
					</li>
					<li class="c-m-bordered-list__item">
						<a class="un-link m-display-block" href="" title="">
							<div class="c-m-box c-m-box--vertical-xl c-m-box--horizontal-m">
							<div class="">
								<div class="ds-o-flex__item"><h1 class="c-m-heading c-m-heading--l">採用単価表変更のお知らせ</h1></div>
								<div class="ds-o-flex__item"><span class="c-m-text c-m-text--grey m-fw-bold c-m-text--helvetica c-m-text--s-short">2018/11/20 00:11</span></div>
							</div>
						</div>
						</a>
					</li>
					<li class="c-m-bordered-list__item">
						<a class="un-link m-display-block" href="" title="">
							<div class="c-m-box c-m-box--vertical-xl c-m-box--horizontal-m">
							<div class="">
								<div class="ds-o-flex__item"><h1 class="c-m-heading c-m-heading--l">採用単価表変更のお知らせ</h1></div>
								<div class="ds-o-flex__item"><span class="c-m-text c-m-text--grey m-fw-bold c-m-text--helvetica c-m-text--s-short">2018/11/20 00:11</span></div>
							</div>
						</div>
						</a>
					</li>
					<li class="c-m-bordered-list__item">
						<a class="un-link m-display-block" href="" title="">
							<div class="c-m-box c-m-box--vertical-xl c-m-box--horizontal-m">
							<div class="">
								<div class="ds-o-flex__item"><h1 class="c-m-heading c-m-heading--l">採用単価表変更のお知らせ</h1></div>
								<div class="ds-o-flex__item"><span class="c-m-text c-m-text--grey m-fw-bold c-m-text--helvetica c-m-text--s-short">2018/11/20 00:11</span></div>
							</div>
						</div>
						</a>
					</li>
				</ul>
				</div>
		</div>				
	</div>
<?php include('announcements_popup_mobile.php') ?>
<?php include('layout/mobile_footer.php') ?>
