<div class="modal fade" id="fill-popup" tabindex="-1" role="dialog" aria-labelledby="myModalLabel2" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <div class="c-m-page-header__title">
                  <h1 class="c-m-heading m-fw-bold">求人を選択</h1>
                </div>
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span>
                </button>
            </div>
            <div class="modal-body">
             <ul class="c-m-bordered-list">
              <li class="c-m-bordered-list__item">
                <a class="c-m-box-link"><span class="c-m-text c-m-text--black m-fw-bold m-fs-sm">神奈川県 ライフサポート訪問看護リハビリステーション菊名 看護師/准看護師 (正看護師) パート・バイト</span></a>
              </li>
               <li class="c-m-bordered-list__item">
                <a class="c-m-box-link"><span class="c-m-text c-m-text--black m-fw-bold m-fs-sm">神奈川県 ライフサポート訪問看護リハビリステーション菊名 理学療法士 正職員</span></a>
              </li> 
              <li class="c-m-bordered-list__item">
                <a class="c-m-box-link"><span class="c-m-text c-m-text--black m-fw-bold m-fs-sm">神奈川県 ライフサポート訪問看護リハビリステーション菊名 作業療法士 正職員</span></a>
              </li> 
              <li class="c-m-bordered-list__item">
                <a class="c-m-box-link"><span class="c-m-text c-m-text--black m-fw-bold m-fs-sm">神奈川県 ライフサポート訪問看護リハビリステーション菊名 理学療法士 パート・バイト</span></a>
              </li>
              <li class="c-m-bordered-list__item">
                <a class="c-m-box-link"><span class="c-m-text c-m-text--black m-fw-bold m-fs-sm">神奈川県 ライフサポート訪問看護リハビリステーション菊名 作業療法士 パート・バイト</span></a>
              </li>
            </ul>
            </div>
            
        </div>
    </div>
  </div>
 